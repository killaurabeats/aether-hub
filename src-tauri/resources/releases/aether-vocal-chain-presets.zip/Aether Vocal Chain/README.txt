AETHER VOCAL CHAIN — v1.1

Preset pack for AetherVocal Strip. The .aetherpreset files are JSON and
document the exact module values used in the demo mix. Install with
Aether Hub; the pack lands in FL Studio's Presets folder.
