AETHER 808 ESSENTIALS — v1.1
Original samples generated for Aether Hub.
Drums: 24-bit-ready one-shots, tuned to A. Previews contain a 4-bar demo.
Drop this folder into your sampler or FL Studio browser.
